<!--
*** Written by Sandeep Yadav ***
 -->

Library can be created using following command -->

npx create-next-library

This folder containes the code for library of Radio and CheckBox components.

And, can be installed using

npm i ../form-elements

After copying this library and pasting in the same folder of application.

Some criterias to note :--

    --> "id" prop is required for library to work !!!
    --> "label" prop is required for displaying label beside the radio or checkbox !!!
