"use client";

import { useState } from "react";
import BaseLayout from "../../components/BaseLayout";
import { Table, Switch } from "next-ts-lib";
import "next-ts-lib/dist/index.css"
import AcceptIcon from "./icons/AcceptIcon";
import RoleDrawer from "./drwer";

export default function Home() {
    const [dummyData, setDummyData] = useState("");

    console.log(dummyData);
        if(dummyData === "Add"){
            
        }
    const headers = [
        {
            heading: "ID",
            field: "id",
            sort: true,

        },
        {
            heading: "Title",
            field: "title",
            sort: true,
        },
        {
            heading: "Thumbnail",
            field: "thumbnail",
            sort: false,
        },
        {
            heading: "Price",
            field: "price",
            sort: true,
        },
        {
            heading: "Category",
            field: "category",
            sort: true,
        },
        {
            heading: "Status",
            field: "status",
            sort: true,
        },

    ];
    let jsonData = [
        {
            id: 1,
            title:"Alvish",
            city: "Prayagraj",
            category:"Alvishsfsdfdfdsfsdfsdfdsf"
        },
        {
            id: 2,
            name: "Vipin",
            age: 23,
            city: "Lucknow",
            category:"Alvishsfsdfdfdsdfsdfsdfsdfsdffsdfsdsfsdfsdfdsf"
        },
        {
            id: 3,
            name: "Saksham",
            age: 21,
            city: "Noida",
            category:"Alvishsfsdfdfdsadfsdfdffsfsdfdfdfsdfsdfdsf"
        },
    ];
    const actionButtons = (
            <span className="flex justify-center items-center cursor-pointer">
                <AcceptIcon />
            </span>
    );
    const actions = [
        actionButtons
      ];
   

    const dummy = {
        thumbnail: (item: any) => <Switch checked />,
        status:(item: any) => <Switch checked />,
    }

    const actionarry = [
        "Add","Update","Delete"
    ]

    return (
        <>
        <BaseLayout>
            <h5 className="m-5 pt-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
                Table
            </h5>
            <div className="p-2 m-3 bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                <h2 className="m-7 text-xl tracking-tight text-gray-900 dark:text-white">
                    Basic
                </h2>
                <div className="h-auto ml-7">
                    {jsonData.length > 0 && (
                        <Table
                            data={jsonData}
                            headers={headers}
                            actions={actions}
                            getRowId={(jsonData: any)=>{jsonData.id}}
                            JsxComponents={dummy}
                            actionDesc={actionarry}
                            getAction = {setDummyData}
                            sticky={true}
                            sortable
                            action
                            selected
                        />
                    )}
                </div>
            </div>
        </BaseLayout>
        </>
    );
}