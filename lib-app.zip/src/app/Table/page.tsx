"use client"

import { useEffect, useState } from "react";
import BaseLayout from "../../components/BaseLayout";
import { Table } from "next-ts-lib";
import "next-ts-lib/dist/index.css";

const TableComponent: React.FC = () => {
    const [dummyData, setDummyData] = useState([]);

    const dummyDataHandler = async () => {
        const response = await fetch("https://dummyjson.com/products");
        const resData = await response.json();
        setDummyData(resData.products);
    };
    console.log(Object.values(dummyData));

    useEffect(() => {
        dummyDataHandler();
    }, []);

    const headers = ["id", "thumbnail", "title", "price", "category"];

    const actions: any[] | undefined = [];

    const acceptButton = <button type="button">hello</button>;

    actions.push(acceptButton);


    return (
        <>
            <BaseLayout>
                <h5 className="m-5 pt-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
                    Table
                </h5>
                <div className="p-2 m-3 bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                    <h2 className="m-7 text-xl tracking-tight text-gray-900 dark:text-white">
                        Basic
                    </h2>
                    <div className="h-auto ml-7">

                        {dummyData.length > 0 && (
                            <Table
                                className=""
                                data={dummyData}
                                headers={headers}
                                actions={actions}
                                sortable
                                sticky
                                selected
                                action
                            />
                        )}

                    </div>
                </div>
            </BaseLayout>

        </>
    );
};

export default TableComponent;
