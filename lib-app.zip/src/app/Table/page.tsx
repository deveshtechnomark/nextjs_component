"use client";

import { useEffect, useState } from "react";
import BaseLayout from "../../components/BaseLayout";
import { Table } from "next-ts-lib";
import "next-ts-lib/dist/index.css"

import AcceptIcon from "./icons/AcceptIcon";
import DeleteIcon from "./icons/DeleteIcon";
import RejectIcon from "./icons/RejectIcon";

export default function Home() {
    const [dummyData, setDummyData] = useState([]);

    // Fetching data from API
    const dummyDataHandler = async () => {
        const response = await fetch("https://dummyjson.com/products");
        const resData = await response.json();
        setDummyData(resData.products);
    };

    useEffect(() => {
        dummyDataHandler();
    }, []);

    const headers = [
        {
            heading: "ID",
            field: "id",
            sort: true,
        },
        {
            heading: "Title",
            field: "title",
            sort: true,
        },
        {
            heading: "Thumbnail",
            field: "thumbnail",
            sort: false,
        },
        {
            heading: "Price",
            field: "price",
            sort: true,
        },
        {
            heading: "Category",
            field: "category",
            sort: true,
        },
    ];

    const handleAccept = (rowId: any) => {
        console.log("Accepted row with ID:", rowId);
    };

    const handleDelete = (rowId: any) => {
        console.log("Deleted row with ID:", rowId);
    };

    const handleReject = (rowId: any) => {
        console.log("Rejected row with ID:", rowId);
    };

    const actionButtons = (
        <span className="flex items-center justify-evenly">
            <span>
                <AcceptIcon />
            </span>
            <span>
                <DeleteIcon />
            </span>
            <span>
                <RejectIcon />
            </span>
        </span>
    );

    const actions = [actionButtons];

    return (
        <BaseLayout>
            <h5 className="m-5 pt-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
                Table
            </h5>
            <div className="p-2 m-3 bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                <h2 className="m-7 text-xl tracking-tight text-gray-900 dark:text-white">
                    Basic
                </h2>
                <div className="h-auto ml-7">
                    {dummyData.length > 0 && (
                        <Table
                            data={dummyData}
                            headers={headers}
                            actions={actions}
                            sortable
                            action
                            sticky
                            selected
                        />
                    )}
                </div>
            </div>
        </BaseLayout>
    );
}