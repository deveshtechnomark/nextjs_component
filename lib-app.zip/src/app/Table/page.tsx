"use client";

import { useEffect, useState } from "react";
import BaseLayout from "../../components/BaseLayout";
import { Table,Switch} from "next-ts-lib";
import "next-ts-lib/dist/index.css"

import AcceptIcon from "./icons/AcceptIcon";

export default function Home() {
    const [dummyData, setDummyData] = useState([]);
    

    // Fetching data from API
    const dummyDataHandler = async () => {
        const response = await fetch("https://dummyjson.com/products");
        const resData = await response.json();
        setDummyData(resData.products);
    };

    useEffect(() => {
        dummyDataHandler();
    }, []);

    const headers = [
        {
            heading: "ID",
            field: "id",
            sort: true,

        },
        {
            heading: "Title",
            field: "title",
            sort: true,
        },
        {
            heading: "Thumbnail",
            field: "thumbnail",
            sort: false,
        },
        {
            heading: "Price",
            field: "price",
            sort: true,
        },
        {
            heading: "Category",
            field: "category",
            sort: true,
        },

    ];
    const handleAccept = (rowId: any) => {
        console.log("Accepted row with ID:", rowId);
    };

    const handleDelete = (rowId: any) => {
        console.log("Deleted row with ID:", rowId);
    };

    const handleReject = (rowId: any) => {
        console.log("Rejected row with ID:", rowId);
    };

    const actionButtons = (
        <span className="flex items-center justify-evenly" onClick={() => {
            console.log("Hello");

        }}>
            <span >
                <AcceptIcon />
            </span>
        </span>
    );

    const actions = [actionButtons];



    let jsonData = [
        {
            id:1,
           title: "Saurabh",
           city: "Prayagraj"
        },
        {
           name: "Vipin",
           age: 23,
           city: "Lucknow",
        },
        {
           name: "Saksham",
           age: 21,
           city: "Noida",
           thumbnail:Switch
        }
     ];

     const [selectedValue, setSelectedValue] = useState<string>("");
     const options = [
        { label: "Option 1", value: "option 1" },
        { label: "Option 2", value: "option 2" },
        { label: "Option 3", value: "option 3" },
        { label: "Hello 1", value: "Hello 1" },
        { label: "Hello 11", value: "Hello 11" },
    ];
     const dynamicComponents = {
        thumbnail: (item: any) => <Switch checked />
      };

    return (
        <BaseLayout>
            <h5 className="m-5 pt-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
                Table
            </h5>
            <div className="p-2 m-3 bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                <h2 className="m-7 text-xl tracking-tight text-gray-900 dark:text-white">
                    Basic
                </h2>
                <div className="h-auto ml-7">
                    {jsonData.length > 0 && (
                        <Table
                            data={jsonData}
                            headers={headers}
                            actions={actions}
                            sticky
                            sortable
                            action
                            selected
                            JsxComponents={dynamicComponents}
                        />
                    )}
                </div>
            </div>
        </BaseLayout>
    );
}