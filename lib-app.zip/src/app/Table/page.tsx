"use client";

import { useState } from "react";
import BaseLayout from "../../components/BaseLayout";
import { Table } from "next-ts-lib";
import "next-ts-lib/dist/index.css"
import AcceptIcon from "./icons/AcceptIcon";

export default function Home() {
  const [dummyData, setDummyData] = useState("");

  console.log(dummyData);
  if (dummyData === "Add") {

  }
  const headers = [
    { heading: "ID", field: "id", sort: true },
    { heading: "Name", field: "name", sort: true },
    { heading: "Age", field: "age", sort: true },
  ];
  const data = [
    {
      id: 1,
      name: "John Doe",
      age: 30,
      humnnu: [
        {
          id: 11,
          childName: "Child",
          childAge: 5,
          Alvish: [
            {
              id: 123,
              childName: "Child123",
              childAge: 512847557656,

            },
          ],
        },]

    },
    {
      id: 2,
      name: "Jane Smith",
      age: 25,
      // If there is only one child, it can still be represented as an object
      Alvish: [
        {
          id: 12,
          childName: "Child 2",
          childAge: 8,
          
        },
      ],
    },
  ];
  const actionButtons = (
    <span className="flex justify-center items-center cursor-pointer">
      <AcceptIcon />
    </span>
  );
  const actions = [
    actionButtons
  ];


  // const dummy = {
  //     thumbnail: (item: any) => <Switch checked />,
  //     status:(item: any) => <Switch checked />,
  // }

  const actionarry = [
    "Add", "Update", "Delete"
  ]

  if (!data || data.length === 0) {
    return <div>No data available.</div>; // Render a message or loading state
  }

  return (
    <>
      {/* <BaseLayout>
        <h5 className="m-5 pt-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
          Table
        </h5>
        <div className="p-2 m-3 bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
          <h2 className="m-7 text-xl tracking-tight text-gray-900 dark:text-white">
            Basic
          </h2>
          <div className="h-auto ml-7"> */}

      <Table
        data={data}
        headers={headers}
        actions={actions}
        getRowId={(data: any) => { data.id }}
        // JsxComponents={dummy}
        actionDesc={actionarry}
        getAction={setDummyData}
        actionSticky
        // expandableHeading ={false}
        expandable
        // sticky={true}
        sortable
        action
      // selected
      />


      {/* </div>
        </div>
      </BaseLayout> */}
    </>
  );
}




