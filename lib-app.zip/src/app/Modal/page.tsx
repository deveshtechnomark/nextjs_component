"use client"

import React, { useState } from 'react';
import BaseLayout from "../../components/BaseLayout";
import { Modal, ModalTitle, ModalContent, ModalAction } from "next-ts-lib";
import "next-ts-lib/dist/index.css";

const ModalComponent: React.FC = () => {
    const [smOpen, setSmOpen] = useState(false);
    const [mdOpen, setMdOpen] = useState(false);
    const [lgOpen, setLgOpen] = useState(false);

    const smOpenModal = () => {
        setSmOpen(true);
    };

    const smCloseModal = () => {
        setSmOpen(false);
    };

    const mdOpenModal = () => {
        setMdOpen(true);
    };

    const mdCloseModal = () => {
        setMdOpen(false);
    };
    const lgOpenModal = () => {
        setLgOpen(true);
    };

    const lgCloseModal = () => {
        setLgOpen(false);
    };


    return (
        <BaseLayout>
            <h5 className="m-5 pt-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Modal</h5>
            <div className="p-2 m-3 bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                <h2 className="m-7 text-xl tracking-tight text-gray-900 dark:text-white">Basic Small Variant</h2>
                <div className="pb-4 pl-8">
                    <button onClick={smOpenModal} className="bg-blue-500 text-white px-4 py-2 rounded">
                        Small Modal
                    </button>
                    {smOpen && (
                        <Modal isOpen={smOpen} onClose={smCloseModal} size='sm'>
                            <ModalTitle>
                            </ModalTitle>
                            <ModalContent>
                                This is Modal Content
                            </ModalContent>
                            <ModalAction>
                                <button onClick={smCloseModal} className="bg-red-500 text-white px-4 py-2 rounded mr-2">
                                    Cancel
                                </button>
                                <button onClick={smCloseModal} className="bg-green-500 text-white px-4 py-2 rounded">
                                    Save Changes
                                </button>
                            </ModalAction>
                        </Modal>
                    )}
                </div>
            </div>

            <div className="p-2 m-3 bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                <h2 className="m-7 text-xl tracking-tight text-gray-900 dark:text-white">Basic Medium Variant</h2>
                <div className="pb-4 pl-8">
                    <button onClick={mdOpenModal} className="bg-blue-500 text-white px-4 py-2 rounded">
                        Medium Modal
                    </button>
                    {mdOpen && (
                        <Modal isOpen={mdOpen} onClose={mdCloseModal} size='md'>
                            <ModalTitle>
                            </ModalTitle>
                            <ModalContent>
                                This is Modal Content
                            </ModalContent>
                            <ModalAction>
                                <button onClick={mdCloseModal} className="bg-red-500 text-white px-4 py-2 rounded mr-2">
                                    Cancel
                                </button>
                                <button onClick={mdCloseModal} className="bg-green-500 text-white px-4 py-2 rounded">
                                    Save Changes
                                </button>
                            </ModalAction>
                        </Modal>
                    )}
                </div>
            </div>

            <div className="p-2 m-3 bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                <h2 className="m-7 text-xl tracking-tight text-gray-900 dark:text-white">Basic Large Variant</h2>
                <div className="pb-4 pl-8">
                    <button onClick={lgOpenModal} className="bg-blue-500 text-white px-4 py-2 rounded">
                        Large Modal
                    </button>
                    {lgOpen && (
                        <Modal isOpen={lgOpen} onClose={lgCloseModal} size='lg'>
                            <ModalTitle>
                            </ModalTitle>
                            <ModalContent>
                                This is Modal Content
                            </ModalContent>
                            <ModalAction>
                                <button onClick={lgCloseModal} className="bg-red-500 text-white px-4 py-2 rounded mr-2">
                                    Cancel
                                </button>
                                <button onClick={lgCloseModal} className="bg-green-500 text-white px-4 py-2 rounded">
                                    Save Changes
                                </button>
                            </ModalAction>
                        </Modal>
                    )}
                </div>
            </div>
        </BaseLayout>
    );
};

export default ModalComponent;
